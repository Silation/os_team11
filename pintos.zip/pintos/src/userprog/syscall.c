#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "userprog/signal.h"
#include "userprog/process.h"
#include "threads/malloc.h"
#include "threads/vaddr.h"
#include "vm/page.h"
//#include "userprog/process.c"

/* customized for vm */
#define DO_UNMAP_FOR_ALL 100

static void syscall_handler (struct intr_frame *);

static int get_user(const uint8_t *uaddr);
static bool put_user(uint8_t *udst, uint8_t byte);
struct file* get_file_from_fd(int fd);
bool validate_read(void *p, int size);
bool validate_write(void *p, int size);

/* customized for VM: 3 functions below */
struct vm_entry * check_address(void *addr, void *esp);
bool check_valid_buffer (void* buffer, unsigned size, void* esp, bool to_write);    // validate_read 대체용
bool check_valid_string (const void* str, void* esp);                               // validate_write 대체용

struct vm_entry * check_address(void *addr, void *esp /*unused arg*/){
  if(addr < (void*) 0x08048000 || addr >= (void*) 0xc0000000){
    sys_exit(-1);
  }
  struct vm_entry *temp_entry = find_vme(addr);
  return temp_entry;
}

// validate_read 대체
bool check_valid_buffer (void* buffer, unsigned size, void* esp, bool to_write){
  // buffer부터 buffer + size의 크기는 한 페이지의 크기를 넘을 수 있다.
  // check_address => 주소 영역 검사 && vm_entry 얻음
  // vm_entry가 존재하는지/writable한지 <- buffer ~ buffer+size 검사
  struct vm_entry *temp_entry;

  for(void* addr = pg_round_down(buffer); addr < buffer + size; addr ++){
    temp_entry = check_address(addr, NULL);
    if(temp_entry == NULL || (to_write && temp_entry->writable == false) )
      return false;
  }

  return true;
}

bool check_valid_string (const void* str, void* esp){
  /* str에 대한 vm_entry의 존재 여부 확인 */
  struct vm_entry *temp_entry;
  temp_entry = check_address(str, esp);

  if (temp_entry == NULL)
    return false;
  
  return true;
}




static void (*syscall_table[20])(struct intr_frame*) = {
  sys_halt,
  sys_exit,
  sys_exec,
  sys_wait,
  sys_create,
  sys_remove,
  sys_open,
  sys_filesize,
  sys_read,
  sys_write,
  sys_seek,
  sys_tell,
  sys_close
}; // syscall jmp table

/* Reads a byte at user virtual address UADDR.
  UADDR must be below PHYS_BASE.
  Returns the byte value if successful, -1 if a segfault
  occurred. */
static int
get_user (const uint8_t *uaddr)
{
  int result;
  asm ("movl $1f, %0; movzbl %1, %0; 1:"
        : "=&a" (result) : "m" (*uaddr));
  return result;
}

/* Writes BYTE to user address UDST.
  UDST must be below PHYS_BASE.
  Returns true if successful, false if a segfault occurred. */
static bool
put_user (uint8_t *udst, uint8_t byte)
{
  int error_code;
  asm ("movl $1f, %0; movb %b2, %1; 1:"
        : "=&a" (error_code), "=m" (*udst) : "q" (byte));
  return error_code != -1;
}

struct file* get_file_from_fd(int fd) {

  struct list_elem *e;
  struct thread *t = thread_current();
  struct fd_elem *fd_elem;

  for (e = list_begin (&t->fd_table); e != list_end (&t->fd_table);
       e = list_next (e))
  {
    fd_elem = list_entry (e, struct fd_elem, elem);
    if(fd_elem->fd == fd)
      return fd_elem->file_ptr;
  }
  return NULL;
}

bool validate_read(void *p, int size) {
  int i = 0;
  if(p >= PHYS_BASE || p + size >= PHYS_BASE) return false;
  for(i = 0; i < size; i++) {
    if(get_user(p + i) == -1)
      return false;
  }
  return true;
}

bool validate_write(void *p, int size) {
  int i = 0;
  if(p >= PHYS_BASE || p + size >= PHYS_BASE) return false;
  for(i = 0; i < size; i++) {
    if(put_user(p + i, 0) == false)
      return false;
  }
  return true;
}

void kill_process() {
  send_signal(-1, SIG_WAIT);
  printf ("%s: exit(%d)\n", thread_current()->name, -1);
  thread_exit();
}

void
syscall_init (void) 
{
  lock_init(&file_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f) 
{ 
  /* customized for vm */
  // int syscall_num = validate_read(f->esp, 4) ? *(int*)(f->esp) : -1;
  int syscall_num = check_valid_string(f->esp, f->esp) ? *(int*)(f->esp) : -1;
  
  if(syscall_num < 0 || syscall_num >= 20) {
    kill_process();
  }
  
  (syscall_table[syscall_num])(f);
}

// void halt(void)
void sys_halt (struct intr_frame * f UNUSED) {
  shutdown_power_off();
}

// void exit(int status)
void sys_exit (struct intr_frame * f) {
  int status;
  
  if(!validate_read(f->esp + 4, 4)) kill_process();
  
  status = *(int*)(f->esp + 4);

  send_signal(status, SIG_WAIT);
  printf ("%s: exit(%d)\n", thread_current()->name, status);
  thread_exit();  
}

// pid_t exec(const char *cmd_line)
void sys_exec (struct intr_frame * f) {
  char *cmd_line;
  pid_t pid;
  char *itr;
  
  if(!validate_read(f->esp + 4, 4)) kill_process();
  
  cmd_line = *(char**)(f->esp + 4);
  itr = cmd_line;
  
  if(!validate_read((void*)cmd_line, 1)) kill_process();
  
  while(*itr != '\0') {
    itr++;
    if(!validate_read((void*)itr, 1)) kill_process();
  }
  
  pid = process_execute(cmd_line);
  f->eax = pid == -1 ? pid : get_signal(pid, SIG_EXEC);
}

// int wait (pid_t pid)
void sys_wait (struct intr_frame * f) {
  if(!validate_read(f->esp + 4, 4)) kill_process();
  
  pid_t pid = *(pid_t*)(f->esp + 4);
  
  f->eax = process_wait(pid);
}

//bool create (const char *file, unsigned initial_size)
void sys_create (struct intr_frame * f) {
  char *name;
  unsigned initial_size;
  char *itr;
  
  if(!validate_read(f->esp + 4, 8)) kill_process();
  
  name = *(char **)(f->esp + 4);
  initial_size = *(unsigned*)(f->esp + 8);
  itr = name;
  
  if(!validate_read((void*)name, 1)) kill_process();

  while(*itr != '\0') {
    itr++;
    if(!validate_read((void*)itr, 1)) kill_process();
  }

  lock_acquire(&file_lock);  
  f->eax = filesys_create(name, initial_size);
  lock_release(&file_lock);
}

//bool remove (const char *file)
void sys_remove (struct intr_frame * f) {
  char *name;
  char *itr;
  
  if(!validate_read(f->esp + 4, 4)) kill_process();
  
  name = *(char **)(f->esp + 4);
  itr = name;
  
  if(!validate_read((void*)name, 1)) kill_process();

  while(*itr != '\0') {
    itr++;
    if(!validate_read((void*)itr, 1)) kill_process();
  }
  
  lock_acquire(&file_lock);
  f->eax = filesys_remove(name);
  lock_release(&file_lock);
}

//int open (const char *file)
void sys_open (struct intr_frame * f) {
  char *name;
  char *itr;
  struct thread *t;
  struct file *file;
  struct list_elem *e;
  struct fd_elem *f_elem;
  struct fd_elem *fd_elem;
  
  if(!validate_read(f->esp + 4, 4)) kill_process();

  name = *(char **)(f->esp + 4);
  itr = name;

  if(!validate_read((void*)name, 1)) kill_process();

  while(*itr != '\0') {
    itr++;
    if(!validate_read((void*)itr, 1)) kill_process();
  }
  
  if(itr == name) {
    f->eax = -1;
    return;
  }
  
  t = thread_current();
  file = filesys_open(name); //if fails, it returns NULL
  f_elem = malloc(sizeof(struct fd_elem));
  
  if(file == NULL) {
    f->eax = -1;
    return;
  }

  f_elem->fd = 2;
  f_elem->file_ptr = file;

  for (e = list_begin (&t->fd_table); e != list_end (&t->fd_table);
       e = list_next (e))
  {
    fd_elem = list_entry (e, struct fd_elem, elem);
    if(fd_elem->fd > f_elem->fd) {
      e = list_prev(e);
      list_insert(e, &f_elem->elem);
      f->eax = f_elem->fd;
      return;
    }
    f_elem->fd++;
  }
  list_push_back(&t->fd_table, &f_elem->elem);
  f->eax = f_elem->fd;
}

//int filesize (int fd)
void sys_filesize (struct intr_frame * f) {
  int fd;
  struct file *file;
  
  if(!validate_read(f->esp + 4, 4)) kill_process();
  
  fd = *(int*)(f->esp + 4);
  file = get_file_from_fd(fd);
  
  if(file == NULL) f->eax = -1;
  
  f->eax = file_length(file);
}

//int read (int fd, void *buffer, unsigned size)
void sys_read (struct intr_frame * f) {
  char c;
  unsigned count = 0;
  int fd;
  uint8_t* buffer;
  unsigned size;
  struct file *file;
  
  if(!validate_read(f->esp + 4, 12)) kill_process();
  
  fd = *(int*)(f->esp + 4);
  buffer = *(uint8_t**)(f->esp + 8);
  size = *(unsigned*)(f->esp + 12);
  file = get_file_from_fd(fd); 
  
  // customized for vm
  // if(!validate_write(buffer, size)) kill_process();
  if(!check_valid_buffer(buffer, size, NULL, 1)) kill_process();
  
  if(fd == 0) {
    c = input_getc();
    while(c != '\n' && c != -1 && count < size) {
      if(!put_user(buffer, c)) kill_process();
      buffer++;
      count++;
      c = input_getc();
    }
    f->eax = count;
  }
  else if(fd == 1) {
    f->eax = -1;
  }
  else {
    if(file == NULL) {
      f->eax = -1;
      return;
    }
    lock_acquire(&file_lock);
    f->eax = file_read(file, buffer, size);
    lock_release(&file_lock);
  }
}

//int write (int fd, const void *buffer, unsigned size)
void sys_write (struct intr_frame * f) {
  int fd;
  char* buffer;
  unsigned size;
  struct file *file;
  
  if(!validate_read(f->esp + 4, 12)) kill_process();
  
  fd = *(int*)(f->esp + 4);
  buffer = *(char**)(f->esp + 8);
  size = *(unsigned*)(f->esp + 12);
  file = get_file_from_fd(fd);
  
  // if(!validate_read(buffer, size)) kill_process();
  /* customized for vm */
  if(!check_valid_buffer(buffer, size, NULL, false)) kill_process();
  
  if(fd == 0) {
    f->eax = 0; 
  }
  else if(fd == 1) {
    putbuf(buffer, size);
    f->eax = size;
  }
  else {
    if(file == NULL) {
      f->eax = 0;
      return;
    }
    lock_acquire(&file_lock);
    f->eax = file_write (file, buffer, size);
    lock_release(&file_lock);
  }
}

//void seek (int fd, unsigned position)
void sys_seek (struct intr_frame * f) {
  int fd;
  off_t position;
  struct file *file;
  
  if(!validate_read(f->esp + 4, 8)) kill_process();
  
  fd = *(int*)(f->esp + 4);
  position = *(int*)(f->esp + 8);
  file = get_file_from_fd(fd);  
  
  if(file == NULL) f->eax = -1;
  
  lock_acquire(&file_lock);
  file_seek(file, position);
  lock_release(&file_lock);
}

//unsigned tell (int fd)
void sys_tell (struct intr_frame * f) {
  if(!validate_read(f->esp + 4, 4)) kill_process();
  int fd = *(int*)(f->esp + 4);
  struct file *file = get_file_from_fd(fd);
  if(file == NULL)
    f->eax = -1;
  lock_acquire(&file_lock);
  f->eax = file_tell(file);
  lock_release(&file_lock);
}

//void close (int fd)
void sys_close (struct intr_frame * f) {
  int fd;
  struct file *file;
  struct thread *t;
  struct list_elem *e;
  struct fd_elem *fd_elem;
  
  if(!validate_read(f->esp + 4, 4)) kill_process();
  
  fd = *(int*)(f->esp + 4);
  file = get_file_from_fd(fd);
  t = thread_current();
    
  lock_acquire(&file_lock);
  file_close(file);
  lock_release(&file_lock);
  
  for (e = list_begin (&t->fd_table); e != list_end (&t->fd_table);
       e = list_next (e))
  {
    fd_elem = list_entry (e, struct fd_elem, elem);
    if(fd_elem->fd == fd) {
      list_remove(e);
      free(fd_elem);
      return;
    }
  }
}

/* customized for vm*/
int mmap(int fd, void *upage) {
  struct list_elem *e;

  struct thread *curr = thread_current();

  // 매핑 시작 주소/파일 체크
  if (upage == NULL || pg_ofs(upage) != 0) return -1;
  if (fd <= 1) return -1; // 0, 1 배치 불가

  lock_acquire (&file_lock);

  // 1. Open file
  struct file *f = NULL;
  struct fd_elem* file_d, *temp;

  // fd에 해당하는 file_elem 탐색
  for (e = list_begin (&curr->fd_table); e != list_end (&curr->fd_table);
       e = list_next (e)) {
    temp = list_entry (e, struct fd_elem, elem);
    if(temp->fd == fd)
      file_d = temp;
  }

  if(file_d && file_d->file_ptr) {
    f = file_reopen (file_d->file_ptr);
  }
  if (f != NULL){
    size_t file_size = file_length(f);
    if (file_size != 0){

      /* 2. Mapid 할당 */
      // First, check that all there is no existing page.
      size_t offset;
      bool success;

      for (offset = 0; offset < file_size; offset += PGSIZE){
        void *addr = upage + offset;
        if (find_vme(addr))
          success = false;
      }

      struct vm_entry *temp_entry;
      if (success){
        // 변수 설정
        for (offset = 0; offset < file_size; offset += PGSIZE){
          void *addr = upage + offset;

          size_t read_bytes = (offset + PGSIZE < file_size ? PGSIZE : file_size - offset);
          size_t zero_bytes = PGSIZE - read_bytes;

          load_segment(f, offset, addr,
                              read_bytes, zero_bytes, /*writable*/ true);
          temp_entry = find_vme(addr);
        }

        /* 3. Assign mmapid */
        int mid;
        if (!list_empty(&curr->mmap_list)){
          mid = list_entry(list_back(&curr->mmap_list), struct mmap_file, file_list_elem)->mapid + 1;
        }
        else
          mid = 1;

        // mmap file 생성 및 초기화
        struct mmap_file *mmap_d = (struct mmap_file *)malloc(sizeof(struct mmap_file));
        mmap_d->mapid = mid;
        mmap_d->file = f;
        // mmap_d->vme_list = ;
        list_push_back(&curr->mmap_list, &mmap_d->file_list_elem);
        list_push_back(&mmap_d->vme_list, &temp_entry->mmap_elem);

        lock_release(&file_lock);
        return mid;
      }
    }
  }
  // finally: release and return
  lock_release(&file_lock);
  return -1;
}

void munmap(int mapping){
  struct list_elem *e;

  struct mmap_file* mmap;

  for (e = list_begin (&thread_current()->mmap_list); e != list_end (&thread_current()->mmap_list); e = list_next (e)){
    mmap = list_entry (e, struct mmap_file, file_list_elem);
    if(mapping == DO_UNMAP_FOR_ALL || mmap->mapid == mapping){
      do_munmap(mmap);
      list_remove(e);
      //free(mmap);
    }
  }
}

void do_munmap (struct mmap_file * mmap_file){
  struct list_elem *e;
  struct vm_entry* vme;
  
  for (e = list_begin (&mmap_file->vme_list); e != list_end (&mmap_file->vme_list); e = list_next (e)){
    vme = list_entry (e, struct vm_entry, mmap_elem);

    if (vme->is_loaded){
      if (pagedir_is_dirty(thread_current()->pagedir, vme->vaddr)){
        lock_acquire(&file_lock);
        // Q. size?
        file_write_at(vme->file, vme->vaddr, vme->read_bytes+vme->zero_bytes, vme->offset);
        lock_release(&file_lock);

      }
      palloc_free_page(pagedir_get_page(thread_current()->pagedir, vme->vaddr));
    }
      
    list_remove(e);
    //free(e);
  }
}