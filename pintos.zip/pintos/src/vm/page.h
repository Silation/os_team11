#ifndef VM_PAGE_H
#define VM_PAGE_H

#define VM_BIN      0       // System call(Read/Write) 등으로 binary file로부터 data load (Actively in Memorry)
#define VM_FILE     1       // mapping된 file로부터 data load (from filesys)
#define VM_ANON     2       // swap 영역으로부터 data load (on Swap Slot)

#include "hash.h"
#include "lib/kernel/hash.h"

#include "threads/synch.h"
#include "threads/malloc.h"
#include "threads/palloc.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "threads/thread.h"

struct vm_entry{
    uint8_t type;           // data load type (VM_BIN / FILE / ANON)
    void *vaddr;            // vm_entry가 관리하는 virtual page number
    bool writable;          // 해당 주소에 write 가능한지?

    bool is_loaded;         // Physical frame에 VM이 탑재되었는지
    struct file* file;      // virtual memory address와 연결된 file

    size_t offset;          // 읽어야 할 file offset
    size_t read_bytes;      // Virtual Page에 작성된 데이터 크기
    size_t zero_bytes;      // 0으로 채울 남은 page bytes

    // vm_entry Implementation
    struct hash_elem hash_table_elem;   // vm_entries are managed with 'Chaining hash table' from lib/kernel/hash.*

    // Memory mapped File Implementation
    struct list_elem mmap_elem;         // element to implement mmap list

    // Swapping Implementation
    size_t swap_slot;
};

struct mmap_file{
    int mapid;                          // mmap 성공시 returned id
    struct file* file;                  // 매핑하는 file object
    struct list_elem file_list_elem;    // file들의 list 연결 위한 구조체
    struct list vme_list;               // mmap_file을 share하는 vm_entry 의 list
};



/* vm_entry의 vaddr을 key로 hash값을 반환하는 함수 => vm_init에 사용
    input: vm을 찾고자 하는 hash_elem
    output: 해당 vm의 mapped hash number
*/
static unsigned vm_hash_func(const struct hash_elem *e, void *aux);

/* vm_entry의 vaddr을 key로 hash값을 반환하는 함수 => vm_init에 사용
    input: vm을 찾고자 하는 hash_elem 2개
    output: 해당 vm들의 vaddr이 내림차순 정렬 되어 있는지 여부
*/
static bool vm_less_func(const struct hash_elem *a, const struct hash_elem *b, void *aux);

/*
    vm memory인 hash table을 initialize
*/
void vm_init(struct hash *vm);

/* 특정 vm_entry를 특정 process의 Virtual memory(hash table)에 삽입
    input: 삽입할 vm_entry, 저장할 Virtual memory의 포인터
    output: 삽입 성공 여부 / but, 일단 void로 구현
*/
bool insert_vme (struct hash *vm, struct vm_entry *vme);

/*
    특정 vm_entry를 vm table에서 삭제
*/
bool delete_vme (struct hash *vm, struct vm_entry *vme);

// vm에서 vaddr에 해당하는 vm_entry를 반환
struct vm_entry *find_vme (void *vaddr);

//vm의 chined bucket list와 entries를 제거
void vm_destroy (struct hash *vm);

// page_fault가 발생할 때 handling 가능한 영역이면 true를 반환
bool vm_try_handle_fault(struct intr_frame *f UNUSED, void *addr UNUSED,
						 bool user UNUSED, bool write UNUSED, bool not_present UNUSED);

bool load_file (void* kaddr, struct vm_entry* vme);

#endif