#include <string.h>
#include "lib/kernel/hash.h"

#include "threads/synch.h"
#include "threads/malloc.h"
#include "threads/palloc.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "vm/page.h"
// #include "vm/frame.h"
// #include "filesys/file.h"

struct vm_entry;

void vm_init (struct hash *vm){
    hash_init(vm, vm_hash_func, vm_less_func, NULL);
}

static unsigned vm_hash_func(const struct hash_elem *e, void *aux){

    struct vm_entry *vm_e = hash_entry(e, struct vm_entry, hash_table_elem);
    return hash_int((uint32_t) vm_e->vaddr);
}

static bool vm_less_func(const struct hash_elem *a, const struct hash_elem *b, void *aux){
    struct vm_entry *vm_a = hash_entry(a, struct vm_entry, hash_table_elem);
    struct vm_entry *vm_b = hash_entry(b, struct vm_entry, hash_table_elem);
    
    if (vm_a->vaddr >= vm_b->vaddr){
	    return false;
    }
    return true;
}

bool insert_vme (struct hash *vm, struct vm_entry *vme){
    struct hash_elem *temp = hash_insert(vm, &vme -> hash_table_elem);
    
    return (temp != NULL);
}

bool delete_vme (struct hash *vm, struct vm_entry *vme){
    struct hash_elem *temp = hash_delete(vm, &vme -> hash_table_elem);
    if(temp != NULL){
        return true;
    }
    return false;
}

struct vm_entry *find_vme (void *vaddr){
    struct hash* vm = &thread_current()->vm;

    struct vm_entry *temp_vme; // = (struct vm_entry *)malloc(sizeof(struct vm_entry));
    void *rounded_addr = pg_round_down(vaddr);
    temp_vme->vaddr = rounded_addr;

    struct hash_elem *elem = hash_find(vm, &temp_vme->hash_table_elem);
	
    if(elem == NULL) return NULL;
    
    return hash_entry(elem, struct vm_entry, hash_table_elem);
}

static void
vm_elem_destroy_func(struct hash_elem *vme, void *aux UNUSED){
    struct vm_entry *entry = hash_entry(vme, struct vm_entry, hash_table_elem);

    if(entry -> is_loaded){
        ASSERT(entry->type == VM_FILE);
        // load된 경우에 free하는 함수 구현
        
    }
    else if(entry->type == VM_ANON) {
        // vm_swap에서 free하는 함수 구현
    }
    else if(entry->type == VM_BIN) {
        // storage에 명령어로 연결한 경우에 free하는 함수 구현
    }

    free(entry);
}

void vm_destroy(struct hash *vm){
  ASSERT (vm != NULL);

  hash_destroy (vm, vm_elem_destroy_func);
  free (vm);
}


bool load_file (void* kaddr, struct vm_entry* vme){

    // offset 설정
    file_seek(vme->file, vme ->offset);

    // read_bytes만큼의 data를 물리페이지에 적기
    int n_read = file_read(vme->file, vme ->read_bytes);

    if(n_read != (int)vme->read_bytes)
        return false;

    // 남는 부분의 bytes를 zero로 패딩
    ASSERT (vme->read_bytes + vme->zero_bytes == PGSIZE);
    memset (kaddr + n_read, 0, vme->zero_bytes);
    return true;
}